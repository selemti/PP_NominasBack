using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using PP_NominasBack.Models.Catalogos.Shared;

namespace PP_NominasBack.Dtos.Catalogos.Shared
{
    public class AlertaNotificacionDto
    {
        [Display(Name = "ID único de la alerta")]
        [Required]
        public List<string> Id { get; set; }

        [Display(Name = "Evento que genera la alerta")]
        [Required]
        public List<string> EventoDisparador { get; set; }

        [Display(Name = "Descripción de la alerta")]
        [Required]
        public List<string> DescripcionAlerta { get; set; }

        [Display(Name = "(0 = Única, 1 = Recurrente diaria, 2 = Recurrente semanal)")]
        [Required]
        public List<int?> TipoPeriodicidad { get; set; }

        [Display(Name = "(0 = Correo, 1 = WhatsApp, 2 = Sistema Interno)")]
        [Required]
        public List<int?> MedioEnvio { get; set; }

        [Display(Name = "Mensaje personalizado que se enviará")]
        [Required]
        public List<string> PlantillaMensaje { get; set; }

        [Display(Name = "Indica si la alerta está activa")]
        [Required]
        public List<bool?> Activo { get; set; }

        [Display(Name = "Hereda campos de auditoría")]
        [Required]
        public List<Auditable?> Auditable { get; set; }

    }
}
