using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using PP_NominasBack.Models.Catalogos.Shared;

namespace PP_NominasBack.Models.Catalogos.Nomina
{
    public class ConfiguracionNomina
    {
        [BsonId]
        [BsonElement("Id")]
        public ObjectId Id { get; set; }

        [BsonElement("GrupoEmpresaId")]
        public List<ObjectId?> GrupoEmpresaId { get; set; }
        [BsonElement("TipoNomina")]
        public List<int?> TipoNomina { get; set; }
        [BsonElement("DiasPago")]
        public List<List<int>?> DiasPago { get; set; }
        [BsonElement("CentroTrabajoId")]
        public List<ObjectId?> CentroTrabajoId { get; set; }
        [BsonElement("Auditable")]
        public List<Auditable?> Auditable { get; set; }
    }
}
