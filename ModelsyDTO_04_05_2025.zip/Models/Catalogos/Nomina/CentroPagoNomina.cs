using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using PP_NominasBack.Models.Catalogos.Shared;

namespace PP_NominasBack.Models.Catalogos.Nomina
{
    public class CentroPagoNomina
    {
        [BsonId]
        [BsonElement("Id")]
        public ObjectId Id { get; set; }

        [BsonElement("NombreCentroPago")]
        public List<string> NombreCentroPago { get; set; }
        [BsonElement("FechaCorteQuincena1")]
        public List<int?> FechaCorteQuincena1 { get; set; }
        [BsonElement("FechaCorteQuincena2")]
        public List<int?> FechaCorteQuincena2 { get; set; }
        [BsonElement("FechaPagoQuincena1")]
        public List<int?> FechaPagoQuincena1 { get; set; }
        [BsonElement("FechaPagoQuincena2")]
        public List<int?> FechaPagoQuincena2 { get; set; }
        [BsonElement("Auditable")]
        public List<Auditable?> Auditable { get; set; }
    }
}
