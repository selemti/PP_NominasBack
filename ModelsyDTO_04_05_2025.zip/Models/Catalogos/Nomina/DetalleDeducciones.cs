using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using PP_NominasBack.Models.Catalogos.Shared;

namespace PP_NominasBack.Models.Catalogos.Nomina
{
    public class DetalleDeducciones
    {
        [BsonId]
        [BsonElement("Id")]
        public ObjectId Id { get; set; }

        [BsonElement("ReciboNominaId")]
        public List<ObjectId?> ReciboNominaId { get; set; }
        [BsonElement("TipoDeduccionId")]
        public List<ObjectId?> TipoDeduccionId { get; set; }
        [BsonElement("Monto")]
        public List<decimal?> Monto { get; set; }
        [BsonElement("Auditable")]
        public List<Auditable?> Auditable { get; set; }
    }
}
