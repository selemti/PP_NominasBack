﻿// Models/Catalogos/Nomina/ConceptoFiniquito.cs
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using PP_NominasBack.Models.Catalogos.Shared;

namespace PP_NominasBack.Models.Catalogos.Nomina
{
    public class ConceptoFiniquito : Auditable
    {
        [BsonId]
        public new ObjectId Id { get; set; }

        [BsonElement("FiniquitoLiquidacionId")]
        public ObjectId FiniquitoLiquidacionId { get; set; }

        [BsonElement("Codigo")]
        public string Codigo { get; set; } = null!;

        [BsonElement("Descripcion")]
        public string Descripcion { get; set; } = null!;

        [BsonElement("EsPercepcion")]
        public bool EsPercepcion { get; set; }

        [BsonElement("Importe")]
        public decimal Importe { get; set; }
    }
}
