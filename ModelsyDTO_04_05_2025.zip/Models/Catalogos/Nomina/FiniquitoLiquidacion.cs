// Models/Catalogos/Nomina/FiniquitoLiquidacion.cs
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using PP_NominasBack.Models.Catalogos.Shared;

namespace PP_NominasBack.Models.Catalogos.Nomina
{
    public class FiniquitoLiquidacion : Auditable
    {
        [BsonId]
        public new ObjectId Id { get; set; }

        [BsonElement("EmpleadoId")]
        public ObjectId EmpleadoId { get; set; }

        [BsonElement("FechaFiniquito")]
        public DateTime FechaFiniquito { get; set; }

        [BsonElement("IsrCalculado")]
        public decimal IsrCalculado { get; set; }

        [BsonElement("TotalFiniquito")]
        public decimal TotalFiniquito { get; set; }

        [BsonElement("Conceptos")]
        public List<ConceptoFiniquito> Conceptos { get; set; } = new();
    }
}
