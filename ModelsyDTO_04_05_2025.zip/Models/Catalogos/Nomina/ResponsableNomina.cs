using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using PP_NominasBack.Models.Catalogos.Shared;

namespace PP_NominasBack.Models.Catalogos.Nomina
{
    public class ResponsableNomina
    {
        [BsonId]
        [BsonElement("Id")]
        public ObjectId Id { get; set; }

        [BsonElement("UsuarioId")]
        public List<ObjectId?> UsuarioId { get; set; }
        [BsonElement("TipoResponsabilidad")]
        public List<int?> TipoResponsabilidad { get; set; }
        [BsonElement("CentroPagoNominaId")]
        public List<ObjectId?> CentroPagoNominaId { get; set; }
        [BsonElement("Auditable")]
        public List<Auditable?> Auditable { get; set; }
    }
}
