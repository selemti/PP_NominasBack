
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using PP_NominasBack.Models.Catalogos.Shared;

namespace PP_NominasBack.Models.Catalogos.Nomina
{
    public class ReciboNomina
    {
        [BsonId]
        [BsonElement("Id")]
        public ObjectId Id { get; set; }

        [BsonElement("EmpleadoId")]
        public ObjectId EmpleadoId { get; set; } // Relación con Empleado

        [BsonElement("PeriodoNominaId")]
        public string PeriodoNominaId { get; set; } // Relación con Periodo de Nómina

        [BsonElement("HorasExtrasTrabajadas")]
        public double HorasExtrasTrabajadas { get; set; } // Horas extras trabajadas

        [BsonElement("HorasExtrasAutorizadas")]
        public double HorasExtrasAutorizadas { get; set; } // Horas extras autorizadas

        [BsonElement("TotalPercepciones")]
        public decimal TotalPercepciones { get; set; } // Total de percepciones

        [BsonElement("TotalDeducciones")]
        public decimal TotalDeducciones { get; set; } // Total de deducciones

        [BsonElement("TotalNeto")]
        public decimal TotalNeto { get; set; } // Total neto

        [BsonElement("Auditable")]
        public Auditable Auditable { get; set; } // Información de auditoría
    }
}
