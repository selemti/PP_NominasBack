using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using PP_NominasBack.Models.Catalogos.Shared;

namespace PP_NominasBack.Models.Catalogos.Nomina
{
    public class CfdiNomina
    {
        [BsonId]
        [BsonElement("Id")]
        public ObjectId Id { get; set; }

        [BsonElement("ReciboNominaId")]
        public List<ObjectId?> ReciboNominaId { get; set; }
        [BsonElement("Uuid")]
        public List<string> Uuid { get; set; }
        [BsonElement("SelloDigital")]
        public List<string> SelloDigital { get; set; }
        [BsonElement("FechaTimbre")]
        public List<DateTime?> FechaTimbre { get; set; }
        [BsonElement("Auditable")]
        public List<Auditable?> Auditable { get; set; }
    }
}
