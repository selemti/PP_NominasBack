using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using PP_NominasBack.Models.Catalogos.Shared;

namespace PP_NominasBack.Models.Catalogos.Fiscal
{
    public class TablaIsr
    {
        [BsonId]
        [BsonElement("Id")]
        public ObjectId Id { get; set; }

        [BsonElement("LimiteInferior")]
        public List<decimal?> LimiteInferior { get; set; }
        [BsonElement("LimiteSuperior")]
        public List<decimal?> LimiteSuperior { get; set; }
        [BsonElement("CuotaFija")]
        public List<decimal?> CuotaFija { get; set; }
        [BsonElement("PorcentajeExcedente")]
        public List<decimal?> PorcentajeExcedente { get; set; }
        [BsonElement("Periodo")]
        public List<int?> Periodo { get; set; }
        [BsonElement("EjercicioFiscal")]
        public List<int?> EjercicioFiscal { get; set; }
        [BsonElement("Auditable")]
        public List<Auditable?> Auditable { get; set; }
    }
}
