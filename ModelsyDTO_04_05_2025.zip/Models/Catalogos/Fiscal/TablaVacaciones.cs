using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using PP_NominasBack.Models.Catalogos.Shared;

namespace PP_NominasBack.Models.Catalogos.Fiscal
{
    public class TablaVacaciones
    {
        [BsonId]
        [BsonElement("Id")]
        public ObjectId Id { get; set; }

        [BsonElement("AniosAntiguedadMinimo")]
        public List<int?> AniosAntiguedadMinimo { get; set; }
        [BsonElement("AniosAntiguedadMaximo")]
        public List<int?> AniosAntiguedadMaximo { get; set; }
        [BsonElement("DiasVacaciones")]
        public List<int?> DiasVacaciones { get; set; }
        [BsonElement("EjercicioFiscal")]
        public List<int?> EjercicioFiscal { get; set; }
        [BsonElement("Auditable")]
        public List<Auditable?> Auditable { get; set; }
    }
}
