using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using PP_NominasBack.Models.Catalogos.Shared;

namespace PP_NominasBack.Models.Catalogos.Fiscal
{
    public class TablaImss
    {
        [BsonId]
        [BsonElement("Id")]
        public ObjectId Id { get; set; }

        [BsonElement("Concepto")]
        public List<string> Concepto { get; set; }
        [BsonElement("PorcentajePatronal")]
        public List<decimal?> PorcentajePatronal { get; set; }
        [BsonElement("PorcentajeObrero")]
        public List<decimal?> PorcentajeObrero { get; set; }
        [BsonElement("SalarioMinimoAplica")]
        public List<bool?> SalarioMinimoAplica { get; set; }
        [BsonElement("EjercicioFiscal")]
        public List<int?> EjercicioFiscal { get; set; }
        [BsonElement("Auditable")]
        public List<Auditable?> Auditable { get; set; }
    }
}
