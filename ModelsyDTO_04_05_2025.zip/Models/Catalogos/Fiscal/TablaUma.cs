using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using PP_NominasBack.Models.Catalogos.Shared;

namespace PP_NominasBack.Models.Catalogos.Fiscal
{
    public class TablaUma
    {
        [BsonId]
        [BsonElement("Id")]
        public ObjectId Id { get; set; }

        [BsonElement("ValorUma")]
        public List<decimal?> ValorUma { get; set; }
        [BsonElement("FechaInicioVigencia")]
        public List<DateTime?> FechaInicioVigencia { get; set; }
        [BsonElement("FechaFinVigencia")]
        public List<DateTime?> FechaFinVigencia { get; set; }
        [BsonElement("EjercicioFiscal")]
        public List<int?> EjercicioFiscal { get; set; }
        [BsonElement("Auditable")]
        public List<Auditable?> Auditable { get; set; }
    }
}
