using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using PP_NominasBack.Models.Catalogos.Shared;

namespace PP_NominasBack.Models.Catalogos.Fiscal
{
    public class CuotaObreroPatronal
    {
        [BsonId]
        [BsonElement("Id")]
        public ObjectId Id { get; set; }

        [BsonElement("Concepto")]
        public List<string> Concepto { get; set; }
        [BsonElement("PorcentajePatron")]
        public List<decimal?> PorcentajePatron { get; set; }
        [BsonElement("PorcentajeEmpleado")]
        public List<decimal?> PorcentajeEmpleado { get; set; }
        [BsonElement("VigenciaInicio")]
        public List<DateTime?> VigenciaInicio { get; set; }
        [BsonElement("VigenciaFin")]
        public List<DateTime?> VigenciaFin { get; set; }
        [BsonElement("Auditable")]
        public List<Auditable?> Auditable { get; set; }
    }
}
