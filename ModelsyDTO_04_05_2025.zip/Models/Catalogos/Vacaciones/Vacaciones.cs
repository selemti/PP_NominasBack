using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using PP_NominasBack.Models.Catalogos.Shared;

namespace PP_NominasBack.Models.Catalogos.Vacaciones
{
    public class Vacaciones
    {
        [BsonId]
        [BsonElement("Id")]
        public ObjectId Id { get; set; }

        [BsonElement("EmpleadoId")]
        public List<ObjectId?> EmpleadoId { get; set; }
        [BsonElement("FechaInicio")]
        public List<DateTime?> FechaInicio { get; set; }
        [BsonElement("FechaFin")]
        public List<DateTime?> FechaFin { get; set; }
        [BsonElement("DiasProgramados")]
        public List<int?> DiasProgramados { get; set; }
        [BsonElement("DiasGozados")]
        public List<int?> DiasGozados { get; set; }
        [BsonElement("PeriodoVacacionalId")]
        public List<ObjectId?> PeriodoVacacionalId { get; set; }
        [BsonElement("Auditable")]
        public List<Auditable?> Auditable { get; set; }
    }
}
