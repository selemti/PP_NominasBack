using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using PP_NominasBack.Models.Catalogos.Shared;

namespace PP_NominasBack.Models.Catalogos.Vacaciones
{
    public class PeriodoVacacional
    {
        [BsonId]
        [BsonElement("Id")]
        public ObjectId Id { get; set; }

        [BsonElement("Anio")]
        public List<int?> Anio { get; set; }
        [BsonElement("DiasAsignados")]
        public List<int?> DiasAsignados { get; set; }
        [BsonElement("Auditable")]
        public List<Auditable?> Auditable { get; set; }
    }
}
