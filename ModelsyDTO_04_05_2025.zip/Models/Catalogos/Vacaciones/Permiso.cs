using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using PP_NominasBack.Models.Catalogos.Shared;

namespace PP_NominasBack.Models.Catalogos.Vacaciones
{
    public class Permiso
    {
        [BsonId]
        [BsonElement("Id")]
        public ObjectId Id { get; set; }

        [BsonElement("EmpleadoId")]
        public List<ObjectId?> EmpleadoId { get; set; }
        [BsonElement("TipoPermiso")]
        public List<int?> TipoPermiso { get; set; }
        [BsonElement("FechaInicio")]
        public List<DateTime?> FechaInicio { get; set; }
        [BsonElement("FechaFin")]
        public List<DateTime?> FechaFin { get; set; }
        [BsonElement("RequiereSuplente")]
        public List<bool?> RequiereSuplente { get; set; }
        [BsonElement("ModalidadReposicion")]
        public List<int?> ModalidadReposicion { get; set; }
        [BsonElement("DetalleReposicion")]
        public List<string> DetalleReposicion { get; set; }
        [BsonElement("Auditable")]
        public List<Auditable?> Auditable { get; set; }
    }
}
