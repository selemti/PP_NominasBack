using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using PP_NominasBack.Models.Catalogos.Shared;

namespace PP_NominasBack.Models.Catalogos.Asistencia
{
    public class ChecadaAgregada
    {
        [BsonId]
        [BsonElement("Id")]
        public ObjectId Id { get; set; }

        [BsonElement("EmpleadoId")]
        public ObjectId EmpleadoId { get; set; }

        [BsonElement("Fecha")]
        public DateTime Fecha { get; set; }

        [BsonElement("HoraEntrada")]
        public string HoraEntrada { get; set; }

        [BsonElement("HoraSalida")]
        public string HoraSalida { get; set; }

        [BsonElement("Observaciones")]
        public string Observaciones { get; set; }

        [BsonElement("Auditable")]
        public string Auditable { get; set; }

    }
}
