
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using PP_NominasBack.Models.Catalogos.Shared;

namespace PP_NominasBack.Models.Catalogos.Asistencia
{
    public class Turno
    {
        [BsonId]
        [BsonElement("Id")]
        public ObjectId Id { get; set; }

        [BsonElement("NombreTurno")]
        public List<string> NombreTurno { get; set; }

        [BsonElement("HoraEntrada")]
        public List<string> HoraEntrada { get; set; } // Hora de entrada

        [BsonElement("HoraSalida")]
        public List<string> HoraSalida { get; set; } // Hora de salida

        [BsonElement("TipoTurno")]
        public List<int?> TipoTurno { get; set; } // Tipo de turno (Fijo, Rotativo)

        [BsonElement("Auditable")]
        public List<Auditable?> Auditable { get; set; }
    }
}
