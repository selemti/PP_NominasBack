
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using PP_NominasBack.Models.Catalogos.Shared;

namespace PP_NominasBack.Models.Catalogos.Asistencia
{
    public class CalendarioLaboral
    {
        [BsonId]
        [BsonElement("Id")]
        public ObjectId Id { get; set; }

        [BsonElement("Fecha")]
        public List<DateTime?> Fecha { get; set; } // Fecha de evento (día laboral, festivo, etc.)

        [BsonElement("TipoDia")]
        public List<int?> TipoDia { get; set; } // Tipo de día (laboral, feriado, etc.)

        [BsonElement("DescripcionEvento")]
        public List<string> DescripcionEvento { get; set; } // Descripción del evento (vacaciones, feriado, etc.)

        [BsonElement("EmpresaId")]
        public List<ObjectId?> EmpresaId { get; set; } // Relación con empresa

        [BsonElement("DivisionId")]
        public List<ObjectId?> DivisionId { get; set; } // Relación con división

        [BsonElement("Vigente")]
        public List<bool?> Vigente { get; set; } // Indica si el evento está vigente

        [BsonElement("Auditable")]
        public List<Auditable?> Auditable { get; set; } // Información de auditoría
    }
}
