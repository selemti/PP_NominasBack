using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using PP_NominasBack.Models.Catalogos.Shared;

namespace PP_NominasBack.Models.Catalogos.Asistencia
{
    public class ChecadaRemota
    {
        [BsonId]
        [BsonElement("Id")]
        public ObjectId Id { get; set; }

        [BsonElement("EmpleadoId")]
        public ObjectId EmpleadoId { get; set; }

        [BsonElement("FechaHora")]
        public DateTime FechaHora { get; set; }

        [BsonElement("TipoEvento")]
        public int TipoEvento { get; set; }

        [BsonElement("Latitud")]
        public decimal Latitud { get; set; }

        [BsonElement("Longitud")]
        public decimal Longitud { get; set; }

        [BsonElement("UbicacionId")]
        public ObjectId UbicacionId { get; set; }

        [BsonElement("FotoAdjunta")]
        public string FotoAdjunta { get; set; }

        [BsonElement("Auditable")]
        public string Auditable { get; set; }
    }
}
