using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using PP_NominasBack.Models.Catalogos.Shared;

namespace PP_NominasBack.Models.Catalogos.Asistencia
{
    public class PlantillaMensual
    {
        [BsonId]
        [BsonElement("Id")]
        public ObjectId Id { get; set; }

        [BsonElement("Mes")]
        public List<int?> Mes { get; set; }
        [BsonElement("AO")]
        public List<int?> AO { get; set; }
        [BsonElement("HorarioPlantillaId")]
        public List<ObjectId?> HorarioPlantillaId { get; set; }
        [BsonElement("Auditable")]
        public List<Auditable?> Auditable { get; set; }
    }
}
