using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using PP_NominasBack.Models.Catalogos.Shared;

namespace PP_NominasBack.Models.Catalogos.Asistencia
{
    public class HorarioPlantilla
    {
        [BsonId]
        [BsonElement("Id")]
        public ObjectId Id { get; set; }

        [BsonElement("NombrePlantilla")]
        public List<string> NombrePlantilla { get; set; }
        [BsonElement("DescripcionPlantilla")]
        public List<string> DescripcionPlantilla { get; set; }
        [BsonElement("TurnoId")]
        public List<ObjectId?> TurnoId { get; set; }
        [BsonElement("Auditable")]
        public List<Auditable?> Auditable { get; set; }
    }
}
