
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using PP_NominasBack.Models.Catalogos.Shared;

namespace PP_NominasBack.Models.Catalogos.Asistencia
{
    public class Checada
    {
        [BsonId]
        [BsonElement("Id")]
        public ObjectId Id { get; set; }

        [BsonElement("EmpleadoId")]
        public List<ObjectId?> EmpleadoId { get; set; }

        [BsonElement("FechaHora")]
        public List<DateTime?> FechaHora { get; set; }

        [BsonElement("TipoEvento")]
        public List<int?> TipoEvento { get; set; }

        [BsonElement("DispositivoId")]
        public List<ObjectId?> DispositivoId { get; set; }

        [BsonElement("Auditable")]
        public List<Auditable?> Auditable { get; set; }

        // Nueva propiedad calculada para Horas Trabajadas
        [BsonElement("HorasTrabajadas")]
        public List<double?> HorasTrabajadas { get; set; } // Horas calculadas de la diferencia entre Entrada y Salida

        // Método para calcular HorasTrabajadas (si es necesario)
        public double CalcularHorasTrabajadas(DateTime entrada, DateTime salida)
        {
            return (salida - entrada).TotalHours;
        }
    }
}
