using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using PP_NominasBack.Models.Catalogos.Shared;

namespace PP_NominasBack.Models.Catalogos.Asistencia
{
    public class RangoTolerancia
    {
        [BsonId]
        [BsonElement("Id")]
        public ObjectId Id { get; set; }

        [BsonElement("Codigo")]
        public List<string> Codigo { get; set; }
        [BsonElement("Nombre")]
        public List<string> Nombre { get; set; }
        [BsonElement("MinutosDesde")]
        public List<int?> MinutosDesde { get; set; }
        [BsonElement("MinutosHasta")]
        public List<int?> MinutosHasta { get; set; }
        [BsonElement("Penalizacion")]
        public List<bool?> Penalizacion { get; set; }
        [BsonElement("Auditable")]
        public List<Auditable?> Auditable { get; set; }
    }
}
