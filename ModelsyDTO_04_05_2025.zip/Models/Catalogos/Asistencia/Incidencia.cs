
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using PP_NominasBack.Models.Catalogos.Shared;

namespace PP_NominasBack.Models.Catalogos.Asistencia
{
    public class Incidencia
    {
        [BsonId]
        [BsonElement("Id")]
        public ObjectId Id { get; set; }

        [BsonElement("TipoFalta")]
        public List<int?> TipoFalta { get; set; } // Tipo de incidencia (Falta, Retardo, Permiso)

        [BsonElement("ChecadaId")]
        public ObjectId? ChecadaId { get; set; } // Relación con la checada

        [BsonElement("EstatusIncidencia")]
        public string EstatusIncidencia { get; set; } // Estado de la incidencia (justificada o no)

        [BsonElement("DuracionRetardo")]
        public double? DuracionRetardo { get; set; } // Duración del retardo (en horas)

        [BsonElement("Justificacion")]
        public string Justificacion { get; set; } // Justificación de la incidencia (si aplica)

        [BsonElement("TipoPermiso")]
        public string TipoPermiso { get; set; } // Tipo de permiso (vacaciones, enfermedad, etc.)
    }
}
