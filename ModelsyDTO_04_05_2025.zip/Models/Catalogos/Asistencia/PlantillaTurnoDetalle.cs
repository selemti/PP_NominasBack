using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using PP_NominasBack.Models.Catalogos.Shared;

namespace PP_NominasBack.Models.Catalogos.Asistencia
{
    public class PlantillaTurnoDetalle
    {
        [BsonId]
        [BsonElement("Id")]
        public ObjectId Id { get; set; }

        [BsonElement("PlantillaId")]
        public List<ObjectId?> PlantillaId { get; set; }
        [BsonElement("Fecha")]
        public List<DateTime?> Fecha { get; set; }
        [BsonElement("TurnoId")]
        public List<ObjectId?> TurnoId { get; set; }
        [BsonElement("PlazaId")]
        public List<ObjectId?> PlazaId { get; set; }
        [BsonElement("Auditable")]
        public List<Auditable?> Auditable { get; set; }
    }
}
