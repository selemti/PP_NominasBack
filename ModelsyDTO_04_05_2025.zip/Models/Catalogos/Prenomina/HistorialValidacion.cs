using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using PP_NominasBack.Models.Catalogos.Shared;

namespace PP_NominasBack.Models.Catalogos.Prenomina
{
    public class HistorialValidacion
    {
        [BsonId]
        [BsonElement("Id")]
        public ObjectId Id { get; set; }

        [BsonElement("PeriodoNominaId")]
        public List<ObjectId?> PeriodoNominaId { get; set; }
        [BsonElement("UsuarioValidadorId")]
        public List<ObjectId?> UsuarioValidadorId { get; set; }
        [BsonElement("Resultado")]
        public List<string> Resultado { get; set; }
        [BsonElement("FechaValidacion")]
        public List<DateTime?> FechaValidacion { get; set; }
        [BsonElement("Observaciones")]
        public List<string> Observaciones { get; set; }
        [BsonElement("Auditable")]
        public List<Auditable?> Auditable { get; set; }
    }
}
