using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using PP_NominasBack.Models.Catalogos.Shared;

namespace PP_NominasBack.Models.Catalogos.Prenomina
{
    public class ControlCierrePrenomina
    {
        [BsonId]
        [BsonElement("Id")]
        public ObjectId Id { get; set; }

        [BsonElement("PeriodoNominaId")]
        public List<ObjectId?> PeriodoNominaId { get; set; }
        [BsonElement("FechaCierre")]
        public List<DateTime?> FechaCierre { get; set; }
        [BsonElement("UsuarioCierreId")]
        public List<ObjectId?> UsuarioCierreId { get; set; }
        [BsonElement("Auditable")]
        public List<Auditable?> Auditable { get; set; }
    }
}
