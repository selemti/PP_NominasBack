using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using PP_NominasBack.Models.Catalogos.Shared;

namespace PP_NominasBack.Models.Catalogos.Shared
{
    public class Telefono
    {
        [BsonId]
        [BsonElement("Id")]
        public ObjectId Id { get; set; }

        [BsonElement("TipoEntidad")]
        public List<string> TipoEntidad { get; set; }
        [BsonElement("EntidadId")]
        public List<ObjectId?> EntidadId { get; set; }
        [BsonElement("ClavePais")]
        public List<string> ClavePais { get; set; }
        [BsonElement("NumeroTelefonico")]
        public List<string> NumeroTelefonico { get; set; }
        [BsonElement("Extension")]
        public List<string> Extension { get; set; }
        [BsonElement("TipoTelefono")]
        public List<int?> TipoTelefono { get; set; }
        [BsonElement("Auditable")]
        public List<Auditable?> Auditable { get; set; }
    }
}
