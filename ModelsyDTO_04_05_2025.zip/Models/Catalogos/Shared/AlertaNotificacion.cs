using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using PP_NominasBack.Models.Catalogos.Shared;

namespace PP_NominasBack.Models.Catalogos.Shared
{
    public class AlertaNotificacion
    {
        [BsonId]
        [BsonElement("Id")]
        public ObjectId Id { get; set; }

        [BsonElement("EventoDisparador")]
        public List<string> EventoDisparador { get; set; }
        [BsonElement("DescripcionAlerta")]
        public List<string> DescripcionAlerta { get; set; }
        [BsonElement("TipoPeriodicidad")]
        public List<int?> TipoPeriodicidad { get; set; }
        [BsonElement("MedioEnvio")]
        public List<int?> MedioEnvio { get; set; }
        [BsonElement("PlantillaMensaje")]
        public List<string> PlantillaMensaje { get; set; }
        [BsonElement("Activo")]
        public List<bool?> Activo { get; set; }
        [BsonElement("Auditable")]
        public List<Auditable?> Auditable { get; set; }
    }
}
