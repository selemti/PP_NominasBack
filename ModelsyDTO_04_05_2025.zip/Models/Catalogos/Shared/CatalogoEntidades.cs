using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using PP_NominasBack.Models.Catalogos.Shared;

namespace PP_NominasBack.Models.Catalogos.Shared
{
    public class CatalogoEntidades
    {
        [BsonId]
        [BsonElement("Id")]
        public ObjectId Id { get; set; }

        [BsonElement("EntityCode")]
        public List<string> EntityCode { get; set; }
        [BsonElement("NombreEntidad")]
        public List<string> NombreEntidad { get; set; }
        [BsonElement("ModuloRelacionado")]
        public List<string> ModuloRelacionado { get; set; }
        [BsonElement("DescripcionEntidad")]
        public List<string> DescripcionEntidad { get; set; }
        [BsonElement("Auditable")]
        public List<Auditable?> Auditable { get; set; }
    }
}
