using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;

namespace PP_NominasBack.Models.Catalogos.Shared
{
    public class Direccion
    {
        [BsonId]
        [BsonElement("Id")]
        public ObjectId Id { get; set; }

        [BsonElement("Calle")]
        public List<string> Calle { get; set; }
        [BsonElement("NumeroExterior")]
        public List<string> NumeroExterior { get; set; }
    }
}
