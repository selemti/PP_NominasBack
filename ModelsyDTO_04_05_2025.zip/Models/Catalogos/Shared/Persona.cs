using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;

namespace PP_NominasBack.Models.Catalogos.Shared
{
    public class Persona
    {
        [BsonId]
        [BsonElement("Id")]
        public ObjectId Id { get; set; }

        [BsonElement("Curp")]
        public List<string> Curp { get; set; }
        [BsonElement("Rfc")]
        public List<string> Rfc { get; set; }
        [BsonElement("Email")]
        public List<string> Email { get; set; }
        [BsonElement("Nacionalidad")]
        public List<string> Nacionalidad { get; set; }
        [BsonElement("Direccion")]
        public List<Direccion?> Direccion { get; set; }
        [BsonElement("Telefonos")]
        public List<List<Telefono>?> Telefonos { get; set; }
    }
}
