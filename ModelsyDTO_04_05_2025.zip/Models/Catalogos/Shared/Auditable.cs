using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;

namespace PP_NominasBack.Models.Catalogos.Shared
{
    public abstract class Auditable
    {
        [BsonId]
        [BsonElement("Id")]
        public ObjectId Id { get; set; }
        // TODO: Add audit properties (CreatedAt, UpdatedAt, etc.)
    }
}
