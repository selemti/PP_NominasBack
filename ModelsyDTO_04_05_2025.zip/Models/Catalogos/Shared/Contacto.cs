using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using PP_NominasBack.Models.Catalogos.Shared;

namespace PP_NominasBack.Models.Catalogos.Shared
{
    public class Contacto
    {
        [BsonId]
        [BsonElement("Id")]
        public ObjectId Id { get; set; }

        [BsonElement("TipoEntidad")]
        public List<string> TipoEntidad { get; set; }
        [BsonElement("EntidadId")]
        public List<ObjectId?> EntidadId { get; set; }
        [BsonElement("NombreContacto")]
        public List<string> NombreContacto { get; set; }
        [BsonElement("TelefonoContacto")]
        public List<string> TelefonoContacto { get; set; }
        [BsonElement("Parentesco")]
        public List<string> Parentesco { get; set; }
        [BsonElement("Auditable")]
        public List<Auditable?> Auditable { get; set; }
    }
}
