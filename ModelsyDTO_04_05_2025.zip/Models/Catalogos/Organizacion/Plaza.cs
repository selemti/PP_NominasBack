using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using PP_NominasBack.Models.Catalogos.Shared;

namespace PP_NominasBack.Models.Catalogos.Organizacion
{
    public class Plaza
    {
        [BsonId]
        [BsonElement("Id")]
        public ObjectId Id { get; set; }

        [BsonElement("ClavePlaza")]
        public List<string> ClavePlaza { get; set; }
        [BsonElement("NombrePlaza")]
        public List<string> NombrePlaza { get; set; }
        [BsonElement("PuestoId")]
        public List<ObjectId?> PuestoId { get; set; }
        [BsonElement("DepartamentoId")]
        public List<ObjectId?> DepartamentoId { get; set; }
        [BsonElement("EstatusPlaza")]
        public List<int?> EstatusPlaza { get; set; }
        [BsonElement("Auditable")]
        public List<Auditable?> Auditable { get; set; }
    }
}
