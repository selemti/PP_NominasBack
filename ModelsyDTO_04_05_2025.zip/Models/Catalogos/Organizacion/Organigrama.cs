using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using PP_NominasBack.Models.Catalogos.Shared;

namespace PP_NominasBack.Models.Catalogos.Organizacion
{
    public class Organigrama
    {
        [BsonId]
        [BsonElement("Id")]
        public ObjectId Id { get; set; }

        [BsonElement("DivisionId")]
        public List<ObjectId?> DivisionId { get; set; }
        [BsonElement("PuestoId")]
        public List<ObjectId?> PuestoId { get; set; }
        [BsonElement("CentroCostoId")]
        public List<ObjectId?> CentroCostoId { get; set; }
        [BsonElement("NodoPadreId")]
        public List<ObjectId?> NodoPadreId { get; set; }
        [BsonElement("Nivel")]
        public List<int?> Nivel { get; set; }
        [BsonElement("Auditable")]
        public List<Auditable?> Auditable { get; set; }
    }
}
