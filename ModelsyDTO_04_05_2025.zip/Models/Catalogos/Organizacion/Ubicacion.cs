using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using PP_NominasBack.Models.Catalogos.Shared;

namespace PP_NominasBack.Models.Catalogos.Organizacion
{
    public class Ubicacion
    {
        [BsonId]
        [BsonElement("Id")]
        public ObjectId Id { get; set; }

        [BsonElement("Nombre")]
        public List<string> Nombre { get; set; }
        [BsonElement("Latitud")]
        public List<decimal?> Latitud { get; set; }
        [BsonElement("Longitud")]
        public List<decimal?> Longitud { get; set; }
        [BsonElement("Radio")]
        public List<decimal?> Radio { get; set; }
        [BsonElement("TipoUbicacion")]
        public List<int?> TipoUbicacion { get; set; }
        [BsonElement("Auditable")]
        public List<Auditable?> Auditable { get; set; }
    }
}
