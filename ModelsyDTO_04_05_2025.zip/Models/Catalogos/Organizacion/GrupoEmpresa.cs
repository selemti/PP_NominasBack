using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using PP_NominasBack.Models.Catalogos.Shared;

namespace PP_NominasBack.Models.Catalogos.Organizacion
{
    public class GrupoEmpresa
    {
        [BsonId]
        [BsonElement("Id")]
        public ObjectId Id { get; set; }

        [BsonElement("Clave")]
        public List<string> Clave { get; set; }
        [BsonElement("Nombre")]
        public List<string> Nombre { get; set; }
        [BsonElement("Rfc")]
        public List<string> Rfc { get; set; }
        [BsonElement("Auditable")]
        public List<Auditable?> Auditable { get; set; }
    }
}
