using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using PP_NominasBack.Models.Catalogos.Shared;

namespace PP_NominasBack.Models.Catalogos.Prestaciones
{
    public class CatalogoPrestaciones
    {
        [BsonId]
        [BsonElement("Id")]
        public ObjectId Id { get; set; }

        [BsonElement("NombrePrestacion")]
        public List<string> NombrePrestacion { get; set; }
        [BsonElement("DescripcionPrestacion")]
        public List<string> DescripcionPrestacion { get; set; }
        [BsonElement("AplicaEmpresaId")]
        public List<ObjectId?> AplicaEmpresaId { get; set; }
        [BsonElement("AplicaDivisionId")]
        public List<ObjectId?> AplicaDivisionId { get; set; }
        [BsonElement("Auditable")]
        public List<Auditable?> Auditable { get; set; }
    }
}
