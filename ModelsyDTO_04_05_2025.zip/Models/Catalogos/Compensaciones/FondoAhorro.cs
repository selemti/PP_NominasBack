using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using PP_NominasBack.Models.Catalogos.Shared;

namespace PP_NominasBack.Models.Catalogos.Compensaciones
{
    public class FondoAhorro
    {
        [BsonId]
        [BsonElement("Id")]
        public ObjectId Id { get; set; }

        [BsonElement("EmpleadoId")]
        public List<ObjectId?> EmpleadoId { get; set; }
        [BsonElement("SaldoActual")]
        public List<decimal?> SaldoActual { get; set; }
        [BsonElement("PorcentajeAportacion")]
        public List<decimal?> PorcentajeAportacion { get; set; }
        [BsonElement("Vigente")]
        public List<bool?> Vigente { get; set; }
        [BsonElement("Auditable")]
        public List<Auditable?> Auditable { get; set; }
    }
}
