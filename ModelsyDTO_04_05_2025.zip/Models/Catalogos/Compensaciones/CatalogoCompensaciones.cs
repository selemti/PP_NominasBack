using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using PP_NominasBack.Models.Catalogos.Shared;

namespace PP_NominasBack.Models.Catalogos.Compensaciones
{
    public class CatalogoCompensaciones
    {
        [BsonId]
        [BsonElement("Id")]
        public ObjectId Id { get; set; }

        [BsonElement("TipoCompensacion")]
        public List<int?> TipoCompensacion { get; set; }
        [BsonElement("NombreCompensacion")]
        public List<string> NombreCompensacion { get; set; }
        [BsonElement("DescripcionCompensacion")]
        public List<string> DescripcionCompensacion { get; set; }
        [BsonElement("AplicaEmpresaId")]
        public List<ObjectId?> AplicaEmpresaId { get; set; }
        [BsonElement("AplicaDivisionId")]
        public List<ObjectId?> AplicaDivisionId { get; set; }
        [BsonElement("Auditable")]
        public List<Auditable?> Auditable { get; set; }
    }
}
