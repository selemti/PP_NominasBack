using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using PP_NominasBack.Models.Catalogos.Shared;

namespace PP_NominasBack.Models.Catalogos.Compensaciones
{
    public class MovimientoFondoAhorro
    {
        [BsonId]
        [BsonElement("Id")]
        public ObjectId Id { get; set; }

        [BsonElement("FondoAhorroId")]
        public List<ObjectId?> FondoAhorroId { get; set; }
        [BsonElement("TipoMovimiento")]
        public List<int?> TipoMovimiento { get; set; }
        [BsonElement("Monto")]
        public List<decimal?> Monto { get; set; }
        [BsonElement("FechaMovimiento")]
        public List<DateTime?> FechaMovimiento { get; set; }
        [BsonElement("Descripcion")]
        public List<string> Descripcion { get; set; }
        [BsonElement("Auditable")]
        public List<Auditable?> Auditable { get; set; }
    }
}
