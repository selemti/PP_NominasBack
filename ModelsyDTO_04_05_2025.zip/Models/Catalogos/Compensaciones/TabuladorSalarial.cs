using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using PP_NominasBack.Models.Catalogos.Shared;

namespace PP_NominasBack.Models.Catalogos.Compensaciones
{
    public class TabuladorSalarial
    {
        [BsonId]
        [BsonElement("Id")]
        public ObjectId Id { get; set; }

        [BsonElement("PuestoId")]
        public List<ObjectId?> PuestoId { get; set; }
        [BsonElement("SalarioMinimo")]
        public List<decimal?> SalarioMinimo { get; set; }
        [BsonElement("SalarioMaximo")]
        public List<decimal?> SalarioMaximo { get; set; }
        [BsonElement("Auditable")]
        public List<Auditable?> Auditable { get; set; }
    }
}
