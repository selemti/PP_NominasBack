using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using PP_NominasBack.Models.Catalogos.Shared;

namespace PP_NominasBack.Models.Catalogos.Empleados
{
    public class DatosPagoEmpleado
    {
        [BsonId]
        [BsonElement("Id")]
        public ObjectId Id { get; set; }

        [BsonElement("EmpleadoId")]
        public List<ObjectId?> EmpleadoId { get; set; }
        [BsonElement("BancoId")]
        public List<ObjectId?> BancoId { get; set; }
        [BsonElement("CuentaBancaria")]
        public List<string> CuentaBancaria { get; set; }
        [BsonElement("FormaPago")]
        public List<int?> FormaPago { get; set; }
        [BsonElement("Vigente")]
        public List<bool?> Vigente { get; set; }
        [BsonElement("FechaInicio")]
        public List<DateTime?> FechaInicio { get; set; }
        [BsonElement("FechaFin")]
        public List<DateTime?> FechaFin { get; set; }
        [BsonElement("Auditable")]
        public List<Auditable?> Auditable { get; set; }
    }
}
