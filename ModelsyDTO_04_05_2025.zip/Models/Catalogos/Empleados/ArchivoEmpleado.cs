using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using PP_NominasBack.Models.Catalogos.Shared;

namespace PP_NominasBack.Models.Catalogos.Empleados
{
    public class ArchivoEmpleado
    {
        [BsonId]
        [BsonElement("Id")]
        public ObjectId Id { get; set; }

        [BsonElement("EmpleadoId")]
        public List<ObjectId?> EmpleadoId { get; set; }
        [BsonElement("TipoArchivo")]
        public List<int?> TipoArchivo { get; set; }
        [BsonElement("UrlArchivo")]
        public List<string> UrlArchivo { get; set; }
        [BsonElement("FechaCarga")]
        public List<DateTime?> FechaCarga { get; set; }
        [BsonElement("Vigente")]
        public List<bool?> Vigente { get; set; }
        [BsonElement("Auditable")]
        public List<Auditable?> Auditable { get; set; }
    }
}
