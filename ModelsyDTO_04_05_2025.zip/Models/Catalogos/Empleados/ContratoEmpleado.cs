using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using PP_NominasBack.Models.Catalogos.Shared;

namespace PP_NominasBack.Models.Catalogos.Empleados
{
    public class ContratoEmpleado
    {
        [BsonId]
        [BsonElement("Id")]
        public ObjectId Id { get; set; }

        [BsonElement("EmpleadoId")]
        public List<ObjectId?> EmpleadoId { get; set; }
        [BsonElement("TipoContrato")]
        public List<int?> TipoContrato { get; set; }
        [BsonElement("FechaInicioContrato")]
        public List<DateTime?> FechaInicioContrato { get; set; }
        [BsonElement("FechaFinContrato")]
        public List<DateTime?> FechaFinContrato { get; set; }
        [BsonElement("vigente")]
        public List<bool?> vigente { get; set; }
        [BsonElement("Auditable")]
        public List<Auditable?> Auditable { get; set; }
    }
}
