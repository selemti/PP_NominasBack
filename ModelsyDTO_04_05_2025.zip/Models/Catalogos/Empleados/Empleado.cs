using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System.Collections.Generic;
using PP_NominasBack.Models.Catalogos.Shared;

namespace PP_NominasBack.Models.Catalogos.Empleados
{
    public class Empleado
    {
        [BsonElement("Curp")]
        public string Curp { get; set; }
        [BsonElement("Rfc")]
        public string Rfc { get; set; }
        [BsonElement("Email")]
        public string Email { get; set; }
        [BsonElement("ContactosEmergencia")]
        public List<EmpleadoContacto> ContactosEmergencia { get; set; }
        [BsonElement("Documentos")]
        public List<ArchivoEmpleado> Documentos { get; set; }
        // ... other properties
    }
}