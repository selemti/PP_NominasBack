using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using PP_NominasBack.Models.Catalogos.Shared;

namespace PP_NominasBack.Models.Catalogos.Empleados
{
    public class HistorialPlazaEmpleado
    {
        [BsonId]
        [BsonElement("Id")]
        public ObjectId Id { get; set; }

        [BsonElement("EmpleadoId")]
        public List<ObjectId?> EmpleadoId { get; set; }
        [BsonElement("PlazaIdAnterior")]
        public List<string> PlazaIdAnterior { get; set; }
        [BsonElement("PlazaIdNueva")]
        public List<string> PlazaIdNueva { get; set; }
        [BsonElement("FechaCambio")]
        public List<DateTime?> FechaCambio { get; set; }
        [BsonElement("MotivoCambio")]
        public List<string> MotivoCambio { get; set; }
        [BsonElement("Auditable")]
        public List<Auditable?> Auditable { get; set; }
    }
}
