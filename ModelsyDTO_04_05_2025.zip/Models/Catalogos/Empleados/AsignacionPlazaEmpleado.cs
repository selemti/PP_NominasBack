using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using PP_NominasBack.Models.Catalogos.Shared;

namespace PP_NominasBack.Models.Catalogos.Empleados
{
    public class AsignacionPlazaEmpleado
    {
        [BsonId]
        [BsonElement("Id")]
        public ObjectId Id { get; set; }

        [BsonElement("EmpleadoId")]
        public List<ObjectId?> EmpleadoId { get; set; }
        [BsonElement("PlazaId")]
        public List<ObjectId?> PlazaId { get; set; }
        [BsonElement("Salario")]
        public List<decimal?> Salario { get; set; }
        [BsonElement("TipoSalario")]
        public List<int?> TipoSalario { get; set; }
        [BsonElement("FechaInicio")]
        public List<DateTime?> FechaInicio { get; set; }
        [BsonElement("FechaFin")]
        public List<DateTime?> FechaFin { get; set; }
        [BsonElement("Vigente")]
        public List<bool?> Vigente { get; set; }
        [BsonElement("Auditable")]
        public List<Auditable?> Auditable { get; set; }
    }
}
