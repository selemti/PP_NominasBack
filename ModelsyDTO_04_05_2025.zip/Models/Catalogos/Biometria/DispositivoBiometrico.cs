using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using PP_NominasBack.Models.Catalogos.Shared;

namespace PP_NominasBack.Models.Catalogos.Biometria
{
    public class DispositivoBiometrico
    {
        [BsonId]
        [BsonElement("Id")]
        public ObjectId Id { get; set; }

        [BsonElement("Modelo")]
        public List<string> Modelo { get; set; }
        [BsonElement("NumeroSerie")]
        public List<string> NumeroSerie { get; set; }
        [BsonElement("IpAsignada")]
        public List<string> IpAsignada { get; set; }
        [BsonElement("TipoDispositivo")]
        public List<int?> TipoDispositivo { get; set; }
        [BsonElement("Auditable")]
        public List<Auditable?> Auditable { get; set; }
        [BsonElement("CentroId")]
        public List<ObjectId?> CentroId { get; set; }
    }
}
