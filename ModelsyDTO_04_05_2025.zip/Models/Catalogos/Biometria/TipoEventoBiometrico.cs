using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using PP_NominasBack.Models.Catalogos.Shared;

namespace PP_NominasBack.Models.Catalogos.Biometria
{
    public class TipoEventoBiometrico
    {
        [BsonId]
        [BsonElement("Id")]
        public ObjectId Id { get; set; }

        [BsonElement("NombreEvento")]
        public List<string> NombreEvento { get; set; }
        [BsonElement("DescripcionEvento")]
        public List<string> DescripcionEvento { get; set; }
        [BsonElement("Activo")]
        public List<bool?> Activo { get; set; }
        [BsonElement("Auditable")]
        public List<Auditable?> Auditable { get; set; }
    }
}
