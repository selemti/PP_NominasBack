using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using PP_NominasBack.Models.Catalogos.Shared;

namespace PP_NominasBack.Models.Catalogos.Biometria
{
    public class LogsSincronizacion
    {
        [BsonId]
        [BsonElement("Id")]
        public ObjectId Id { get; set; }

        [BsonElement("DispositivoId")]
        public List<ObjectId?> DispositivoId { get; set; }
        [BsonElement("FechaEvento")]
        public List<DateTime?> FechaEvento { get; set; }
        [BsonElement("DescripcionLog")]
        public List<string> DescripcionLog { get; set; }
        [BsonElement("Auditable")]
        public List<Auditable?> Auditable { get; set; }
    }
}
