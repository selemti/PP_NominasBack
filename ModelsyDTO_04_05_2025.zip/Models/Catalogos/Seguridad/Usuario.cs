using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using PP_NominasBack.Models.Catalogos.Shared;

namespace PP_NominasBack.Models.Catalogos.Seguridad
{
    public class Usuario
    {
        [BsonId]
        [BsonElement("Id")]
        public ObjectId Id { get; set; }

        [BsonElement("NombreUsuario")]
        public List<string> NombreUsuario { get; set; }
        [BsonElement("CorreoElectronico")]
        public List<string> CorreoElectronico { get; set; }
        [BsonElement("PerfilId")]
        public List<ObjectId?> PerfilId { get; set; }
        [BsonElement("EstatusUsuario")]
        public List<int?> EstatusUsuario { get; set; }
        [BsonElement("Auditable")]
        public List<Auditable?> Auditable { get; set; }
    }
}
