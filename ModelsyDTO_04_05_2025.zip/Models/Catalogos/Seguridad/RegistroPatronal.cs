using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using PP_NominasBack.Models.Catalogos.Shared;

namespace PP_NominasBack.Models.Catalogos.Seguridad
{
    public class RegistroPatronal
    {
        [BsonId]
        [BsonElement("Id")]
        public ObjectId Id { get; set; }

        [BsonElement("Nombre")]
        public List<string> Nombre { get; set; }
        [BsonElement("Rfc")]
        public List<string> Rfc { get; set; }
        [BsonElement("NumeroRegistro")]
        public List<string> NumeroRegistro { get; set; }
        [BsonElement("Subdelegacion")]
        public List<string> Subdelegacion { get; set; }
    }
}
