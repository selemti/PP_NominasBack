using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using PP_NominasBack.Models.Catalogos.Shared;

namespace PP_NominasBack.Models.Catalogos.Seguridad
{
    public class HistorialRegistroImss
    {
        [BsonId]
        [BsonElement("Id")]
        public ObjectId Id { get; set; }

        [BsonElement("EmpleadoId")]
        public List<string> EmpleadoId { get; set; }
        [BsonElement("Nss")]
        public List<string> Nss { get; set; }
        [BsonElement("RegistroPatronalId")]
        public List<string> RegistroPatronalId { get; set; }
        [BsonElement("FechaAlta")]
        public List<DateTime?> FechaAlta { get; set; }
        [BsonElement("FechaBaja")]
        public List<DateTime?> FechaBaja { get; set; }
    }
}
