using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using PP_NominasBack.Models.Catalogos.Shared;

namespace PP_NominasBack.Models.Catalogos.Incidencias
{
    public class PreNominaIncidencia
    {
        [BsonId]
        [BsonElement("Id")]
        public ObjectId Id { get; set; }

        [BsonElement("EmpleadoId")]
        public List<ObjectId?> EmpleadoId { get; set; }
        [BsonElement("PeriodoNominaId")]
        public List<ObjectId?> PeriodoNominaId { get; set; }
        [BsonElement("TipoIncidenciaId")]
        public List<ObjectId?> TipoIncidenciaId { get; set; }
        [BsonElement("Fecha")]
        public List<DateTime?> Fecha { get; set; }
        [BsonElement("Duracion")]
        public List<decimal?> Duracion { get; set; }
        [BsonElement("JustificanteAdjunto")]
        public List<string> JustificanteAdjunto { get; set; }
        [BsonElement("Estatus")]
        public List<string> Estatus { get; set; }
        [BsonElement("Auditable")]
        public List<Auditable?> Auditable { get; set; }
    }
}
