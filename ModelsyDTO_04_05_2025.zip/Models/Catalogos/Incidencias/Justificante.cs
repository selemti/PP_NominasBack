using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using PP_NominasBack.Models.Catalogos.Shared;

namespace PP_NominasBack.Models.Catalogos.Incidencias
{
    public class Justificante
    {
        [BsonId]
        [BsonElement("Id")]
        public ObjectId Id { get; set; }

        [BsonElement("TipoJustificante")]
        public List<int?> TipoJustificante { get; set; }
        [BsonElement("UrlDocumento")]
        public List<string> UrlDocumento { get; set; }
        [BsonElement("FechaEmision")]
        public List<DateTime?> FechaEmision { get; set; }
        [BsonElement("Auditable")]
        public List<Auditable?> Auditable { get; set; }
    }
}
