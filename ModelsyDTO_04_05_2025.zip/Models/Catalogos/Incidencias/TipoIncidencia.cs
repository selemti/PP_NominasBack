using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using PP_NominasBack.Models.Catalogos.Shared;

namespace PP_NominasBack.Models.Catalogos.Incidencias
{
    public class TipoIncidencia
    {
        [BsonId]
        [BsonElement("Id")]
        public ObjectId Id { get; set; }

        [BsonElement("NombreTipoIncidencia")]
        public List<string> NombreTipoIncidencia { get; set; }
        [BsonElement("DescripcionTipoIncidencia")]
        public List<string> DescripcionTipoIncidencia { get; set; }
        [BsonElement("RequiereJustificante")]
        public List<bool?> RequiereJustificante { get; set; }
        [BsonElement("Auditable")]
        public List<Auditable?> Auditable { get; set; }
    }
}
