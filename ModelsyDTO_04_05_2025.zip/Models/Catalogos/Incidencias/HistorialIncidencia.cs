using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using PP_NominasBack.Models.Catalogos.Shared;

namespace PP_NominasBack.Models.Catalogos.Incidencias
{
    public class HistorialIncidencia
    {
        [BsonId]
        [BsonElement("Id")]
        public ObjectId Id { get; set; }

        [BsonElement("IncidenciaId")]
        public List<ObjectId?> IncidenciaId { get; set; }
        [BsonElement("FechaCambio")]
        public List<DateTime?> FechaCambio { get; set; }
        [BsonElement("DescripcionCambio")]
        public List<string> DescripcionCambio { get; set; }
        [BsonElement("Auditable")]
        public List<Auditable?> Auditable { get; set; }
    }
}
