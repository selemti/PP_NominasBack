using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using PP_NominasBack.Models.Catalogos.Shared;

namespace PP_NominasBack.Models.Catalogos.Deducciones
{
    public class CatalogoDeducciones
    {
        [BsonId]
        [BsonElement("Id")]
        public ObjectId Id { get; set; }

        [BsonElement("TipoDeduccion")]
        public List<int?> TipoDeduccion { get; set; }
        [BsonElement("NombreDeduccion")]
        public List<string> NombreDeduccion { get; set; }
        [BsonElement("DescripcionDeduccion")]
        public List<string> DescripcionDeduccion { get; set; }
        [BsonElement("AplicaEmpresaId")]
        public List<ObjectId?> AplicaEmpresaId { get; set; }
        [BsonElement("Auditable")]
        public List<Auditable?> Auditable { get; set; }
    }
}
