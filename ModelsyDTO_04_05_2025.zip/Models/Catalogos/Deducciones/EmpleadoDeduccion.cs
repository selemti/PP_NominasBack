using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using PP_NominasBack.Models.Catalogos.Shared;

namespace PP_NominasBack.Models.Catalogos.Deducciones
{
    public class EmpleadoDeduccion
    {
        [BsonId]
        [BsonElement("Id")]
        public ObjectId Id { get; set; }

        [BsonElement("EmpleadoId")]
        public List<ObjectId?> EmpleadoId { get; set; }
        [BsonElement("DeduccionId")]
        public List<ObjectId?> DeduccionId { get; set; }
        [BsonElement("Valor")]
        public List<decimal?> Valor { get; set; }
        [BsonElement("Periodicidad")]
        public List<int?> Periodicidad { get; set; }
        [BsonElement("FechaInicio")]
        public List<DateTime?> FechaInicio { get; set; }
        [BsonElement("FechaFin")]
        public List<DateTime?> FechaFin { get; set; }
        [BsonElement("Auditable")]
        public List<Auditable?> Auditable { get; set; }
    }
}
