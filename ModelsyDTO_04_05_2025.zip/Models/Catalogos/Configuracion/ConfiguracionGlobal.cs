using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using PP_NominasBack.Models.Catalogos.Shared;

namespace PP_NominasBack.Models.Catalogos.Configuracion
{
    public class ConfiguracionGlobal
    {
        [BsonId]
        [BsonElement("Id")]
        public ObjectId Id { get; set; }

        [BsonElement("CategoriaConfiguracion")]
        public List<string> CategoriaConfiguracion { get; set; }
        [BsonElement("ClaveConfiguracion")]
        public List<string> ClaveConfiguracion { get; set; }
        [BsonElement("ValorConfiguracion")]
        public List<string> ValorConfiguracion { get; set; }
        [BsonElement("DescripcionConfiguracion")]
        public List<string> DescripcionConfiguracion { get; set; }
        [BsonElement("FechaInicioVigencia")]
        public List<DateTime?> FechaInicioVigencia { get; set; }
        [BsonElement("FechaFinVigencia")]
        public List<DateTime?> FechaFinVigencia { get; set; }
        [BsonElement("Auditable")]
        public List<Auditable?> Auditable { get; set; }
    }
}
