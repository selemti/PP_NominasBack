using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using PP_NominasBack.Models.Catalogos.Shared;

namespace PP_NominasBack.Models.Catalogos.Configuracion
{
    public class Modulo
    {
        [BsonId]
        [BsonElement("Id")]
        public ObjectId Id { get; set; }

        [BsonElement("Nombre")]
        public List<string> Nombre { get; set; }
        [BsonElement("Descripcion")]
        public List<string> Descripcion { get; set; }
        [BsonElement("Activo")]
        public List<bool?> Activo { get; set; }
        [BsonElement("Auditable")]
        public List<Auditable?> Auditable { get; set; }
    }
}
